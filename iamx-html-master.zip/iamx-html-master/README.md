# I AM X
I AM X is a minimalist, modern and well-crafted responsive HTML5 resume template for any kind of creative professionals to show their education, experience, skills, and works history in a perfect way.

![alt text](http://trendytheme.net/wp-content/uploads/edd/2015/10/Futani-Admin-Board-Preview-11.jpg "iamx")

#Demo:
<a href="http://trendytheme.net/demo/iamx/v/" target="_blank">Template Demo</a>

#License: 
Use it freely but please do not republish, distribute or sell "as-is". Please credit the designer and developer when you use it in your project.

#Credits: 
- <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>
- <a href="https://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a>
- <a href="https://daneden.github.io/animate.css/" target="_blank">Animate.css</a>
- <a href="http://dimsemenov.com/plugins/magnific-popup/" target="_blank">Magnific Popup</a>
- <a href="https://github.com/protonet/jquery.inview" target="_blank">Inview JS</a>
- <a href="http://vestride.github.io/Shuffle/" target="_blank">Shuffle</a>

#Misc
Follow Ahmed: <a href="https://twitter.com/ahmedfaruk_me" target="_blank">Twitter</a>, <a href="https://www.facebook.com/ahmedfaruk.me" target="_blank">Facebook</a>, <a href="https://plus.google.com/u/0/114068300126923667161" target="_blank">Google+</a>

<a href="http://trendytheme.net/" target="_blank">&copy; trendytheme </a>
